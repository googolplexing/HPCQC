# Copyright (c) 2026 Michael Mucciardi
# SPDX-License-Identifier: SSPL-1.0
"""Aer GPU backend — statevector and density matrix simulation on AMD MI250X.

Phase 3 addition: noise model support for Q50 benchmarking.
When backend_params.noise_model_file is set, builds a NoiseModel from
Q50 calibration data and applies it to the simulator. This requires
method: density_matrix and shots > 0.

Contains all tested knowledge from lumi_vqa:
  - decompose_for_aer(): multi-round decomposition to primitive gates
  - Precision: double by default, single configurable
  - Cache blocking for large qubit counts
  - save_expectation_value for energy evaluation
"""

from __future__ import annotations

from typing import Any

import numpy as np

from lumi_hpc_qc.backends.base import Backend
from lumi_hpc_qc.types import (
    BackendCapabilities,
    CircuitJob,
    CircuitResult,
    ExperimentConfig,
)

# Gates that qiskit-aer can execute directly
_AER_PRIMITIVE_GATES = {
    'x', 'y', 'z', 'h', 's', 'sdg', 't', 'tdg', 'sx', 'sxdg',
    'rx', 'ry', 'rz', 'rxx', 'ryy', 'rzz', 'cx', 'cy', 'cz',
    'cp', 'crx', 'cry', 'crz', 'ccx', 'csx', 'swap', 'cswap',
    'u', 'u1', 'u2', 'u3', 'p', 'id', 'ecr', 'measure', 'barrier',
    'save_expectation_value', 'save_statevector',
}


def decompose_for_aer(circuit, max_rounds=10):
    """Decompose circuit until all gates are Aer-compatible primitives.

    EfficientSU2, EvolvedOps (UCCSD), and other composite gates must be
    decomposed before Aer can execute them. A single decompose() only
    strips one layer of nesting — we need multiple rounds.
    """
    for round_i in range(max_rounds):
        needs_more = False
        for inst in circuit.data:
            if inst.operation.name not in _AER_PRIMITIVE_GATES:
                needs_more = True
                break
        if not needs_more:
            return circuit, round_i
        circuit = circuit.decompose()
    return circuit, max_rounds


class AerGpuBackend(Backend):
    """Qiskit Aer GPU backend — statevector and density matrix simulation."""

    name = "aer_gpu"

    def __init__(self, config: ExperimentConfig | None = None) -> None:
        self._config = config
        self._sim = None
        self._precision = "double"
        self._use_blocking = False
        self._blocking_qubits = 0
        self._noise_model = None
        self._noise_model_file = None
        self._shots = 0  # 0 = statevector (no shots)

        if config:
            self._precision = config.precision
            bp = config.backend_params
            self._method = bp.get("method", "statevector")
            self._noise_model_file = bp.get("noise_model_file", None)
            self._shots = bp.get("shots", 0)

            # Cache blocking for large qubit counts
            nq = config.num_qubits
            if self._precision == "double" and nq and nq >= 30:
                self._use_blocking = True
                self._blocking_qubits = 29
            elif self._precision == "single" and nq and nq >= 30:
                self._use_blocking = True
                self._blocking_qubits = 28
        else:
            self._method = "statevector"

    def _ensure_sim(self) -> None:
        """Lazily initialize AerSimulator (avoids import at module load)."""
        if self._sim is not None:
            return

        from qiskit_aer import AerSimulator

        # Build noise model if calibration file specified
        if self._noise_model_file:
            from lumi_hpc_qc.backends.noise_model import build_noise_model
            import os

            # Resolve path relative to project dir
            cal_path = self._noise_model_file
            project_dir = os.environ.get("PROJECT_DIR",
                          os.environ.get("SINGULARITYENV_PROJECT_DIR", "."))
            if not os.path.isabs(cal_path):
                cal_path = os.path.join(project_dir, cal_path)

            num_qubits = self._config.num_qubits if self._config else 8
            self._noise_model = build_noise_model(cal_path, num_qubits)
            print(f"  Noise model loaded from: {self._noise_model_file}")

        # Determine device — use GPU if available, fall back to CPU
        device = 'GPU'
        if self._noise_model is not None:
            # Noisy simulation: density_matrix on GPU if possible
            device = 'GPU'

        sim_kwargs = dict(
            method=self._method,
            device=device,
            precision=self._precision,
        )
        if self._noise_model is not None:
            sim_kwargs["noise_model"] = self._noise_model

        self._sim = AerSimulator(**sim_kwargs)

    def run_circuits(self, jobs: list[CircuitJob]) -> list[CircuitResult]:
        import time
        self._ensure_sim()
        results = []

        for job in jobs:
            t0 = time.time()
            energies = []

            for i, circuit in enumerate(job.circuits):
                # Bind parameters if provided
                if job.parameters and i < len(job.parameters):
                    param_dict = job.parameters[i]
                    bound = circuit.assign_parameters(param_dict)
                else:
                    bound = circuit

                # Determine shots for this job
                shots = job.shots if job.shots > 0 else self._shots

                # Add expectation value measurement if observable provided
                if job.observable is not None:
                    if shots == 0:
                        # Statevector mode — exact expectation
                        bound.save_expectation_value(
                            job.observable,
                            list(range(circuit.num_qubits)),
                            label='energy',
                        )
                    else:
                        # Shot-based mode — need measurement
                        if not any(inst.operation.name == 'measure' for inst in bound.data):
                            bound.measure_all()

                r = self._sim.run(
                    bound, shots=shots, seed_simulator=42,
                    blocking_enable=self._use_blocking,
                    blocking_qubits=self._blocking_qubits,
                ).result()

                if shots == 0 and job.observable is not None:
                    energy = float(np.real(r.data()['energy']))
                    energies.append(energy)
                elif shots > 0 and job.observable is not None:
                    # Compute expectation from counts
                    counts = r.get_counts()
                    energy = self._expectation_from_counts(
                        counts, job.observable, shots
                    )
                    energies.append(energy)

            elapsed = time.time() - t0
            results.append(CircuitResult(
                job_id=job.job_id,
                energies=energies if energies else None,
                execution_time_s=elapsed,
                backend_name=self.name,
            ))

        return results

    def compile_circuit(self, circuit):
        """Decompose to Aer-compatible primitive gates."""
        compiled, rounds = decompose_for_aer(circuit)
        if rounds > 0:
            print(f"  Decomposed to primitive gates in {rounds} round(s) "
                  f"→ {compiled.size()} gates, depth {compiled.depth()}")
        return compiled

    def capabilities(self) -> BackendCapabilities:
        return BackendCapabilities(
            max_qubits=44,
            supports_statevector=True,
            supports_density_matrix=True,
            supports_mps=False,
            supports_shots=True,
            requires_gpu=True,
            requires_cpu_only=False,
            slurm_partition="standard-g",
        )

    def validate_config(self, config: ExperimentConfig) -> list[str]:
        errors = []
        nq = config.num_qubits
        if nq and nq > 44:
            errors.append(f"Aer GPU supports max 44 qubits, got {nq}")
        if config.precision == "double" and nq and nq > 36:
            errors.append(
                f"Double precision limited to 36 qubits on LUMI (got {nq}). "
                f"Set precision: single for {nq}q."
            )
        bp = config.backend_params
        if bp.get("noise_model_file") and bp.get("method") == "statevector":
            errors.append(
                "Noise model requires method: density_matrix (not statevector). "
                "Statevector simulation is noiseless by definition."
            )
        return errors

    def estimate_walltime(self, config: ExperimentConfig) -> int:
        nq = config.num_qubits or 12
        maxiter = config.optimizer_params.get("maxiter", 200)
        # Empirical from LUMI testing
        sec_per_eval = {12: 0.007, 18: 0.05, 24: 0.5, 30: 5, 36: 30, 40: 120, 44: 600}
        spe = sec_per_eval.get(nq, 0.007 * (2 ** (nq - 12)))
        # Noisy simulation is ~3-5x slower due to density matrix
        if self._noise_model is not None:
            spe *= 4
        n_params_est = nq * 3
        circuits_per_step = 2 * n_params_est + 1
        total = spe * circuits_per_step * maxiter * 2  # 2x safety
        return max(300, min(int(total), 48 * 3600))

    @staticmethod
    def _expectation_from_counts(counts: dict, observable, total_shots: int) -> float:
        """Compute ⟨H⟩ from measurement counts (for shot-based / noisy simulation).

        Same implementation as IQM QPU backend — shared physics.
        """
        from qiskit.quantum_info import SparsePauliOp
        if not isinstance(observable, SparsePauliOp):
            observable = SparsePauliOp.from_operator(observable)

        energy = 0.0
        for pauli_label, coeff in zip(observable.to_list(), observable.coeffs):
            label = pauli_label[0] if isinstance(pauli_label, tuple) else str(pauli_label)

            if all(c in ('I', 'i') for c in label):
                energy += float(np.real(coeff))
                continue

            z_positions = [i for i, c in enumerate(reversed(label)) if c in ('Z', 'z')]
            if not z_positions:
                energy += float(np.real(coeff))
                continue

            expectation = 0.0
            for bitstring, count in counts.items():
                bits = bitstring.replace(' ', '')
                parity = sum(int(bits[-(pos + 1)]) for pos in z_positions if pos < len(bits))
                expectation += ((-1) ** parity) * count

            energy += float(np.real(coeff)) * expectation / total_shots

        return energy
